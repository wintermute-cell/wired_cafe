Much love to my patrons, who helped make this asset pack possible!

- OD_Garfield 

- DRSAKAMOTO

- @the_reakain

- Liyi Zhang

- Frankie Bays

- @yogakujuku  (mmilburn.ca)

- Zack

- Haldarc

- Zach Tank

- James Hood

- Psyloh Dubs

- Siluman

- @cthulhumishka  (instagram.com/cthulhumishka)

- Jesse Day

- WinterRabbit 

- Bokuman Studio

- Andy Borglind

- Lord Humungus

- Ice Queen OG

- Zaza

- Zach Tank

- Broos Nemanic

- Bambi 

- AzitateKatana

- Charles Tangora

- Nick Lenn

- Raimonds Iodzevics 

- Josh Bossie

- Nemuruibai

- @Deanishes

- Abby K

- Scoopy

- Mara Vertin

- @chrismalmo

- DayExMok

- Jonathan Holt

- Kyle Cespedes

- Dave Hicks

- Krzysztof Wende

- @435O1

- MaFr�

- @moertel  (http://moer.tel/)

- Nicole Martini

- @cheezopath

- @randomhuman

- @pigeonhat

- Jahan

- Sebastian Paul

- Hannah Lise

- Nacho Frades